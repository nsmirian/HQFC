 clc
 clear all
disp('-----------------M_CORE MATRIX----------------- ')
syms wh wl s k KK  Ah Al DKy DKx

lam=[exp(-i*s*wh) 0 0 0
    0 exp(i*s*wh) 0 0
    0 0 exp(-i*s*wl) 0
    0 0 0 exp(i*s*wl)]

disp('-----------------Eigenvector matrix----------------- ')
X=[(2*DKx)/k + ((DKy*k)/4 + (KK*k*(2*DKx + 2))/4)/KK^2    (8*DKx*KK^2 + DKy*k^2 + 2*KK*k^2 + 2*DKx*KK*k^2)/(4*KK^2*k) -i*((k^2 + 4*KK)^(1/2)*(8*DKx*KK^3 + 4*KK^2*k^2 + DKy*k^4))/(4*KK^2*k^3), -i*(k^2 + 4*KK)^(1/2)*(8*DKx*KK^3 + 4*KK^2*k^2 + DKy*k^4)/(4*KK^2*k^3)
  i*(DKx*(-4*KK + k^2))^(1/2)/(k)                          -i*(DKx*(-4*KK + k^2))^(1/2)/(k)                                                     (2*KK*(k^2 - 2*DKx*KK))/k^3                                                     (2*KK*(k^2 - 2*DKx*KK))/k^3
 i*(-4*KK + k^2)^(1/2)*(2*KK - DKy + 2*DKx*KK)/(4*KK^2), -i*(-4*KK + k^2)^(1/2)*(2*KK - DKy + 2*DKx*KK)/(4*KK^2)               -(8*DKx*KK^3 - 4*KK^2*k^2 + 4*DKy*KK*k^2 - DKy*k^4)/(4*KK^2*k^2),               -(8*DKx*KK^3 - 4*KK^2*k^2 + 4*DKy*KK*k^2 - DKy*k^4)/(4*KK^2*k^2)
 DKy/(2*KK) + 1                                           (DKy + 2*KK)/(2*KK)                                       -i*(DKy*(k^2 + 4*KK)^(1/2))/(2*KK)                                       i*(DKy*(k^2 + 4*KK)^(1/2))/(2*KK)];
 

M_core=X*lam*inv(X);

M_core=simple(M_core);
pretty(M_core)