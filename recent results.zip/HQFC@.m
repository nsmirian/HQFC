
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   This program can calculat emittance and beta function     %
%   I  use Morita  paper                                      %
%                       6/26/2013                             %
%                       N S Mirian                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear all
syms wh wl s k KK  Ah Al DKy DKx
% High and low frequency are :
%wh=sqrt(k^2/4+K);
%wl=sqrt(k^2/4-K);


disp('-----------------Eigenvector matrix----------------- ')
X=[(2*DKx)/k + ((DKy*k)/4 + (KK*k*(2*DKx + 2))/4)/KK^2    (8*DKx*KK^2 + DKy*k^2 + 2*KK*k^2 + 2*DKx*KK*k^2)/(4*KK^2*k) -i*((k^2 + 4*KK)^(1/2)*(8*DKx*KK^3 + 4*KK^2*k^2 + DKy*k^4))/(4*KK^2*k^3), -i*(k^2 + 4*KK)^(1/2)*(8*DKx*KK^3 + 4*KK^2*k^2 + DKy*k^4)/(4*KK^2*k^3)
  i*(DKx*(-4*KK + k^2))^(1/2)/(k)                          -i*(DKx*(-4*KK + k^2))^(1/2)/(k)                                                     (2*KK*(k^2 - 2*DKx*KK))/k^3                                                     (2*KK*(k^2 - 2*DKx*KK))/k^3
 i*(-4*KK + k^2)^(1/2)*(2*KK - DKy + 2*DKx*KK)/(4*KK^2), -i*(-4*KK + k^2)^(1/2)*(2*KK - DKy + 2*DKx*KK)/(4*KK^2)               -(8*DKx*KK^3 - 4*KK^2*k^2 + 4*DKy*KK*k^2 - DKy*k^4)/(4*KK^2*k^2),               -(8*DKx*KK^3 - 4*KK^2*k^2 + 4*DKy*KK*k^2 - DKy*k^4)/(4*KK^2*k^2)
 DKy/(2*KK) + 1                                           (DKy + 2*KK)/(2*KK)                                       -i*(DKy*(k^2 + 4*KK)^(1/2))/(2*KK)                                       i*(DKy*(k^2 + 4*KK)^(1/2))/(2*KK)];
 

Xc=[(2*DKx)/k + ((DKy*k)/4 + (KK*k*(2*DKx + 2))/4)/KK^2,  (-i*(-DKx*(4*KK - k^2))^(1/2))/k,          (-(k^2 - 4*KK)^(1/2)*(2*KK - DKy + 2*DKx*KK)*i)/(4*KK^2),                     DKy/(2*KK) + 1
              (8*DKx*KK^2 + DKy*k^2 + 2*KK*k^2 + 2*DKx*KK*k^2)/(4*KK^2*k), ((-DKx*(4*KK - k^2))^(1/2)*i)/k,         ((k^2 - 4*KK)^(1/2)*(2*KK - DKy + 2*DKx*KK)*i)/(4*KK^2),                (DKy + 2*KK)/(2*KK)
((k^2 + 4*KK)^(1/2)*(8*DKx*KK^3 + 4*KK^2*k^2 + DKy*k^4)*i)/(4*KK^2*k^3),      (2*KK*(k^2 - 2*DKx*KK))/k^3, -(8*DKx*KK^3 - 4*KK^2*k^2 + 4*DKy*KK*k^2 - DKy*k^4)/(4*KK^2*k^2), (DKy*(k^2 + 4*KK)^(1/2)*i)/(2*KK)
((k^2 + 4*KK)^(1/2)*(8*DKx*KK^3 + 4*KK^2*k^2 + DKy*k^4)*i)/(4*KK^2*k^3),      (2*KK*(k^2 - 2*DKx*KK))/k^3, -(8*DKx*KK^3 - 4*KK^2*k^2 + 4*DKy*KK*k^2 - DKy*k^4)/(4*KK^2*k^2),  -(DKy*(k^2 + 4*KK)^(1/2)*i)/(2*KK)];
 

R=[cos(k*s/(2)) 0 sin(k*s/(2)) 0
0 cos(k*s/(2)) 0 sin(k*s/(2))
-sin(k*s/(2)) 0 cos(k*s/(2)) 0
0 -sin(k*s/(2)) 0 cos(k*s/(2))];

 %R(-ks/2)
Rn=[cos(k*s/(2)) 0 -sin(k*s/(2)) 0
0 cos(k*s/(2)) 0 -sin(k*s/(2))
sin(k*s/(2)) 0 cos(k*s/(2)) 0
0 sin(k*s/(2)) 0 cos(k*s/(2))];
%Beam bundariescan be discrib to followingmatrix
% S=[2*(Al^2) 0 0 0
%     0 2*(Al^2) 0 0
%     0 0 2*(Ah^2) 0
%     0 0 0 2*(Ah^2)];
% 
% ss=X*S*(Xc)
% SS=simple(ss);
% disp('-----------------matrix in Eq.36 -------------- ')
% pretty(SS)
%  %R(ks/2)
% 
% disp('-----------------sigma(s)in Eq.36 -------------- ')
% sigma1=R*SS*Rn;
% sigma=simple(sigma1);
% pretty(sigma)
% 
% % sigmaX & SigmaY
% 
% sigmaX=[sigma(1,1) sigma(1,2)
%     sigma(2,1) sigma(2,2)];
% emiX=sqrt(det(sigmaX));
% emitX=simple(emiX);
% disp('-----------------emittance in x direction----------- ')
% pretty(emitX)
% 
% sigmaY=[sigma(3,3) sigma(3,4)
%     sigma(4,3) sigma(4,4)];
% emiY=sqrt(det(sigmaY));
% emitY=simple(emiY);
% disp('-----------------emittance in y direction----------- ')
% pretty(emitY)
% 
% betaX=sigma(1,1)/emitX;
% betaxX=simple(betaX);
% disp('-----------------Beta function in x direction------- ')
% pretty(betaxX)
% 
% %______________________________________________________
% %when sigmax=sigmay or emittanceX=emittanceY
% %  Al=(Ah*2*K/k)*[((k^2+4*K)/(k^2-4*K))^(1/4)]

disp('============Second part=================')
disp('===when sigmax=sigmay or emittanceX=emittanceY==')

Al=(Ah*2*KK/k)*[((k^2+4*KK)/(k^2-4*KK))^(1/4)];
S=[2*(Al^2) 0 0 0
    0 2*(Al^2) 0 0
    0 0 2*(Ah^2) 0
    0 0 0 2*(Ah^2)];
SS1=X*S*(Xc);
SS=simple(SS1);
%pretty(SS)
disp('-----------------sigma(s)in Eq.36 -------------- ')

sigma1=R*SS*Rn;
sigma=simple(sigma1);
pretty(sigma)


sigmaX=[sigma(1,1) sigma(1,2)
    sigma(2,1) sigma(2,2)];
% emiX=sqrt(det(sigmaX));
% emitX=simple(emiX);
% emitX=simple(emiX);
% disp('-----------------Emittance in x direction----------- ')
% pretty(emitX)
% 
% sigmaY=[sigma(3,3) sigma(3,4)
%     sigma(4,3) sigma(4,4)];
% emiY=sqrt(det(sigmaY));
% emitY=simple(emiY);
% % emitY=simple(emiY);
% disp('-----------------Emittance in y direction----------- ')
% pretty(emitY)
% 
% betaX=sigma(1,1)/emitX;
% betaxX=simple(betaX);
% disp('-----------------Beta function1 in x direction------- ')
% pretty(betaxX)
%##########################

emi=sqrt(det(sigma));
emitt=simple(emi);
betaX=sigma(1,1)/sqrt(emitt);
beta2X=simple(betaX);
disp('-----------------Beta function2 in x direction------- ')
pretty(beta2X)
