
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   This program can calculat emittance and beta function     %
%   I  use Morita  paper                                      %
%                       8/20/2012                             %
%                       N S Mirian                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear all
syms wh wl s k K  Ah Al
% High and low frequency are :
wh=sqrt(k^2/4+K);
wl=sqrt(k^2/4-K);


%disp('-----------------Eigenvector matrix----------------- ')
X=[i*2*wh/k -i*2*wh/k k/(2*K) k/(2*K)
    2*K/k 2*K/k 0 0 
    1 1 -i*wl/K i*wl/K
    0 0 1 1];
Xc=[-i*2*wh/k 2*K/k 1 0
    i*2*wh/k 2*K/k 1 0
    k/(2*K) 0 i*wl/K 1
    k/(2*K) 0 -i*wl/K 1];


% Beam bundariescan be discrib to followingmatrix
S=[2*(Ah^2) 0 0 0
    0 2*(Ah^2) 0 0
    0 0 2*(Al^2) 0
    0 0 0 2*(Al^2)];

ss=X*S*(Xc);
SS=simple(ss);
disp('-----------------matrix in Eq.36 -------------- ')
pretty(SS)
%  R(ks/2)
R=[cos(k*s/(2)) 0 sin(k*s/(2)) 0
0 cos(k*s/(2)) 0 sin(k*s/(2))
-sin(k*s/(2)) 0 cos(k*s/(2)) 0
0 -sin(k*s/(2)) 0 cos(k*s/(2))];

%  R(-ks/2)
Rn=[cos(k*s/(2)) 0 -sin(k*s/(2)) 0
0 cos(k*s/(2)) 0 -sin(k*s/(2))
sin(k*s/(2)) 0 cos(k*s/(2)) 0
0 sin(k*s/(2)) 0 cos(k*s/(2))];
disp('-----------------sigma(s)in Eq.36 -------------- ')
sigma1=R*SS*Rn;
sigma=simple(sigma1);
pretty(sigma)

% sigmaX & SigmaY

sigmaX=[sigma(1,1) sigma(1,2)
    sigma(2,1) sigma(2,2)];
emiX=sqrt(det(sigmaX));
emitX=simple(emiX);
disp('-----------------emittance in x direction----------- ')
pretty(emitX)

sigmaY=[sigma(3,3) sigma(3,4)
    sigma(4,3) sigma(4,4)];
emiY=sqrt(det(sigmaY));
emitY=simple(emiY);
disp('-----------------emittance in y direction----------- ')
pretty(emitY)

betaX=sigma(1,1)/emitX;
betaxX=simple(betaX);
disp('-----------------Beta function in x direction------- ')
pretty(betaxX)

% ______________________________________________________
%when sigmax=sigmay or emittanceX=emittanceY
%  Al=(Ah*2*K/k)*[((k^2+4*K)/(k^2-4*K))^(1/4)]

disp('============Second part=================')
disp('===when sigmax=sigmay or emittanceX=emittanceY==')

Al=(Ah*2*K/k)*[((k^2+4*K)/(k^2-4*K))^(1/4)];
S=[2*(Ah^2) 0 0 0
    0 2*(Ah^2) 0 0
    0 0 2*(Al^2) 0
    0 0 0 2*(Al^2)];

SS1=X*S*(Xc);
SS=simple(SS1);
%pretty(SS)
disp('-----------------sigma(s)in Eq.36 -------------- ')

sigma1=R*SS*Rn;
sigma=simple(sigma1);
pretty(sigma)


sigmaX=[sigma(1,1) sigma(1,2)
    sigma(2,1) sigma(2,2)];
emiX=sqrt(det(sigmaX));
emitX=simple(emiX);
% emitX=simple(emiX);
disp('-----------------Emittance in x direction----------- ')
pretty(emitX)

sigmaY=[sigma(3,3) sigma(3,4)
    sigma(4,3) sigma(4,4)];
emiY=sqrt(det(sigmaY));
emitY=simple(emiY);
% emitY=simple(emiY);
disp('-----------------Emittance in y direction----------- ')
pretty(emitY)

betaX=sigma(1,1)/emitX;
betaxX=simple(betaX);
disp('-----------------Beta function1 in x direction------- ')
pretty(betaxX)
%##########################

emi=sqrt(det(sigma));
emitt=simple(emi);
betaX=sigma(1,1)/sqrt(emitt);
beta2X=simple(betaX);
disp('-----------------Beta function2 in x direction------- ')
pretty(beta2X)
